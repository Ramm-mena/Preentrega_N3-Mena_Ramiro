from django.urls import path, include
from .views import *

urlpatterns = [
    path('', index, name= 'Inicio' ),
    path('Sucursal/', sucursal, name= 'mod1' ),
    path('Empleado/', empleado, name= 'mod2' ),
    path('Vehiculos/', vehiculo, name= 'mod3' ),
    path('vintageclb/', vintageClb, name="form1"),

]