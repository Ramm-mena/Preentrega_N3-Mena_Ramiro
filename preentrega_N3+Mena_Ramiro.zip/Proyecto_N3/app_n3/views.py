from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from .forms import *
# Create your views here.

def index(request):
    return render(request, 'app_n3/base.html')

def sucursal(request):
    ctx= {'sucursales': Sucursal.objects.all()}
    return render(request, 'app_n3/sucursal.html', ctx )

def empleado(request):
    ctx= {'empleados': Empleado.objects.all()}
    return render(request, 'app_n3/empleado.html', ctx )

def vehiculo(request):
    ctx= {'vehiculos': Vehiculo.objects.all()}
    return render(request, 'app_n3/vehiculo.html', ctx )

def vintageClb(request):
    if request.method == "POST":   
        miForm = vintaje_club(request.POST)
        if miForm.is_valid:
            datos = miForm.cleaned_data
            miembro = Miembro(nombre=datos['nombre'], Apellido=datos['apellido'])
            miembro.save()
            return render(request, "aplicacion/base.html")
    else:
        miForm = vintaje_club()

    return render(request, "app_n3/vintage_club.html" , {"form":miForm})

 

