from django.apps import AppConfig


class AppN3Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_n3'
